package jdr.exia.model.element

data class Position(var x: Int, var y: Int)
