package jdr.exia.view.mainFrame

import java.awt.Graphics
import javax.swing.JPanel


/*This panel is intended to contain the entire list of items that the Game master can use*/
//this is a singleton
object ItemPanel : JPanel() {
    public override fun paintComponent(graphics: Graphics) {
        super.paintComponent(graphics)

        // graphics.drawImage(,X,Y,null);

    }
}
