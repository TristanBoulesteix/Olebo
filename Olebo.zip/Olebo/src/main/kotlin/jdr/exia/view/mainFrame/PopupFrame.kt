package jdr.exia.view.mainFrame

import javax.swing.JFrame

// This is the menu that appears upon launch, it allows the user to chose what to do.
//this is a singleton
object PopupFrame : JFrame()
