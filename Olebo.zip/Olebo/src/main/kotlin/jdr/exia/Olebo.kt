package jdr.exia

import jdr.exia.controller.ViewController

/*fun main() {
    Controller().apply {
        this.initDatas()
        this.start()
    }
}*/

fun main() {
    val viewController = ViewController
}
